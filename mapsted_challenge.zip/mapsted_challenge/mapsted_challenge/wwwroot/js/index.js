﻿
$("#submit_button").click(function(){
    var user_option = $("#sort_option").val();
    var input_data = $("#input_value").val();
    var input_array = [];
    input_array = input_data.split(",");

    if ( input_data == null || input_data == '' || input_data == undefined){
       alert("input is empty, try again!");
       return;
    }
    if (input_array.length > 10){
        alert("no more than 10 values, try again!");
        return;
    }

    for (var i = 0; i < input_array.length; i++){
        if (parseInt(input_array) > 500 ){
            alert("value should be less than 500, try again!");
            return;
        }
    }

    if ( user_option == "select_sort"){
        selectsort();  

    }

    if ( user_option == "bubble_sort" ){
        bubblesort();

    }


});
    
function bubblesort(){
    var input_data = $("#input_value").val();
    var input_array = [];
    input_array = input_data.split(",");
    var virtualArr = [];


    //alert('inputdata:'+ input_data);

    $.ajax({
            type: "POST", 
            async: false,
            url: "../Sort/Bubblesort",  
            dataType: "json",
            data:{
                "input_string" : input_data
            },
            contentType:'application/x-www-form-urlencoded ',
            traditional: true,
            success: function (data) {

                for (var i = 0 ; i < data.length; i++){
                    virtualArr.push(data[i]);
                }
                //alert('virtualArr:'+ virtualArr); 
                animation(virtualArr);

            },
            error: function (){
                alert("error");
            }
        });
    

}


function selectsort(){
    var input_data = $("#input_value").val();
    var input_array = [];
    var virtualArr = [];

    input_array = input_data.split(",");

    //alert('inputdata:'+ input_data);


    $.ajax({
            type: "POST", //提交数据的类型 分为POST和GET
            async: false,
            url: "../Sort/Selectsort",  //提交url 注意url必须小写
            dataType: "json",
            data:{
                "input_string" : input_data
            },
            contentType:'application/x-www-form-urlencoded ',
            traditional: true,
            success: function (data) {

                for (var i = 0 ; i < data.length; i++){
                    virtualArr.push(data[i]);
                }
                //alert('virtualArr:'+ virtualArr); 
                animation(virtualArr);
            },
            error: function (){
                alert("error");
            }
        });
    


}

function draw(arr){
    if (arr == null){
        return;
    }
    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext('2d');

        var maxWidth = canvas.height;

        var width = 20;

        var space =20;


        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.font = "18px serif";

        for (var i = 0; i < arr.length; i++) {
          ctx.fillStyle = '#61C5FE';


          ctx.fillRect(i * (width+space), maxWidth - arr[i], width, arr[i]);
          ctx.fillStyle = '#240be4';

          ctx.fillText(arr[i], i * (width+space), maxWidth - arr[i]-5);
        }
}


function animation(virtualArr){
    //alert("animation is working");
    var interval = 500;
    virtualArr.forEach((item, index) => {
            setTimeout(() => draw(item), index * interval);
        });  
}




